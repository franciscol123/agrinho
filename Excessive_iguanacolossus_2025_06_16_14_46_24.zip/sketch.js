let cesto;
let frutas = [];
let lixo = [];
let pontos = 0;
let vidas = 3;

function setup() {
  createCanvas(600, 400);
  cesto = new Cesto();
}

function draw() {
  background(120, 200, 100);
  fill(255);
  textSize(18);
  text("Pontos: " + pontos, 10, 20);
  text("Vidas: " + vidas, 10, 40);

  cesto.mostrar();
  cesto.mover();

  // Gerar frutas e lixo aleatoriamente
  if (random(1) < 0.02) {
    frutas.push(new ObjetoAleatorio("fruta"));
  }

  if (random(1) < 0.01) {
    lixo.push(new ObjetoAleatorio("lixo"));
  }

  // Atualizar frutas
  for (let i = frutas.length - 1; i >= 0; i--) {
    frutas[i].cair();
    frutas[i].mostrar();
    if (frutas[i].pego(cesto)) {
      pontos += 10;
      frutas.splice(i, 1);
    } else if (frutas[i].y > height) {
      frutas.splice(i, 1);
    }
  }

  // Atualizar lixo
  for (let i = lixo.length - 1; i >= 0; i--) {
    lixo[i].cair();
    lixo[i].mostrar();
    if (lixo[i].pego(cesto)) {
      vidas--;
      lixo.splice(i, 1);
    } else if (lixo[i].y > height) {
      lixo.splice(i, 1);
    }
  }

  // Fim de jogo
  if (vidas <= 0) {
    noLoop();
    textSize(40);
    fill(255, 0, 0);
    text("Fim de Jogo!", width / 2 - 120, height / 2);
  }
}

class Cesto {
  constructor() {
    this.x = width / 2;
    this.y = height - 40;
    this.largura = 80;
  }

  mostrar() {
    fill(139, 69, 19);
    rect(this.x, this.y, this.largura, 20);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }
    this.x = constrain(this.x, 0, width - this.largura);
  }
}

class ObjetoAleatorio {
  constructor(tipo) {
    this.x = random(width);
    this.y = 0;
    this.vel = random(2, 5);
    this.tipo = tipo;
  }

  cair() {
    this.y += this.vel;
  }

  mostrar() {
    if (this.tipo === "fruta") {
      fill(255, 0, 0);
      ellipse(this.x, this.y, 20);
    } else {
      fill(100);
      rect(this.x, this.y, 20, 20);
    }
  }

  pego(cesto) {
    return this.y > cesto.y &&
           this.y < cesto.y + 20 &&
           this.x > cesto.x &&
           this.x < cesto.x + cesto.largura;
  }
}
